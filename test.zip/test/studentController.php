<?php
    if (isset($_POST['addstudent'])) {
        # code...
        try {
            //code...
            $pdo=new pdo("mysql:host=localhost;dbname=track_php","root");
            $fname=validation($_POST['fname']);
            $lname=validation($_POST['lname']);
            $address=validation($_POST['address']);
            $country=validation($_POST['country']);
            $gender=validation($_POST['gender']);
            $email=validation($_POST['email']);
            $password=validation($_POST['password']);
            $department=validation($_POST['department']);
            
            $pdo->query("INSERT INTO student
            SET
                `fname` = '$fname',
                `lname` = '$lname',
                `address` = '$address',
                `country` = '$country',
                `gender` = '$gender',
                `email`='$email',
                `password`='$password',
                `department`='$department'");
                header("Location:list.php");
        } catch (PDOException $e){
            echo $e->getMessage();
        }
        $pdo=null;
    }
    elseif(isset($_GET['delete'])){
        $id=$_GET['id'];

        try {
            //code...
            $pdo = new pdo("mysql:host=localhost;dbname=track_php", "root");
            $pdo->query("delete from student where id=$id");
            header("Location:list.php");
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    elseif(isset($_GET['show'])){
        $id=$_GET['id'];
        try {
            //code...
            $pdo = new pdo("mysql:host=localhost;dbname=track_php", "root");
           $data= $pdo->query("select *  from student where id=$id");
           $studentInfo=$data->fetch(PDO::FETCH_ASSOC);
           $data=json_encode($studentInfo);
           header("Location:show.php?data=$data");
        } catch (PDOException $e) {
           echo $e->getMessage();
        }
       
    }
    elseif(isset($_GET['edit'])){
        $id=$_GET['id'];
        try {
            //code...
            $pdo = new pdo("mysql:host=localhost;dbname=track_php", "root");
           $data= $pdo->query("select *  from student where id=$id");
           $studentInfo=$data->fetch(PDO::FETCH_ASSOC);
           $data=json_encode($studentInfo);
           header("Location:edit.php?data=$data");
        } catch (PDOException $e) {
           echo $e->getMessage();
        }
       
    }
    function validation($data){
        $data=trim($data);
        $data=stripcslashes($data);
        $data=htmlspecialchars($data);
        return $data;
    }
?>